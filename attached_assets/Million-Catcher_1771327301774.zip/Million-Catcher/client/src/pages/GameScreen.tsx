import { useState, useEffect } from 'react';
import { useGame } from '@/hooks/use-game';
import { Button } from '@/components/ui/button';
import { AlertTriangle, CheckCircle2, XCircle } from 'lucide-react';
import { cn } from '@/lib/utils';
import { motion } from 'framer-motion';

const formatMoney = (amount: number) => {
  return new Intl.NumberFormat('es-ES', { style: 'currency', currency: 'EUR', maximumFractionDigits: 0 }).format(amount).replace(/\s/g, '.').replace('€', ' €');
};

export default function GameScreen() {
  const { gameState, questions, playerId, submitAnswer } = useGame();
  const [localBets, setLocalBets] = useState<Record<string, number>>({});
  const [isRevealing, setIsRevealing] = useState(false);
  const [showResult, setShowResult] = useState(false);
  const [countdown, setCountdown] = useState(3);
  const [hasConfirmed, setHasConfirmed] = useState(false);

  const player = gameState?.players.find(p => p.id === playerId);
  const currentQuestionIndex = (player?.questionNumber || 1) - 1;
  const currentQuestion = questions[currentQuestionIndex];
  
  const totalMoney = player?.money || 0;
  const allocatedMoney = Object.values(localBets).reduce((a, b) => a + b, 0);
  const remainingMoney = totalMoney - allocatedMoney;

  useEffect(() => {
    setLocalBets({});
    setShowResult(false);
    setIsRevealing(false);
    setHasConfirmed(false);
    setCountdown(3);
  }, [player?.questionNumber]);

  if (!gameState || !player || !currentQuestion) return null;

  if (player.isEliminated) {
    return (
      <div className="min-h-screen bg-black flex flex-col items-center justify-center p-8 text-center space-y-6">
        <XCircle className="w-24 h-24 text-red-500 animate-pulse" />
        <h1 className="text-5xl font-display text-white uppercase tracking-tighter">❌ ELIMINAT!</h1>
        <p className="text-xl text-red-200">Ho sentim, has perdut tots els teus diners.</p>
        <div className="fixed bottom-4 right-4 text-white/60 text-xs opacity-60">Developed by Walid Rabbou</div>
      </div>
    );
  }

  if (player.hasFinished || gameState.phase === 'podium') {
    return (
      <div className="min-h-screen bg-black text-white p-8 flex flex-col items-center justify-center relative">
        <h1 className="text-4xl font-display text-accent mb-12 uppercase">Joc Finalitzat</h1>
        <div className="bg-white/5 p-8 rounded-3xl border border-white/10 text-center space-y-4">
          <CheckCircle2 className="w-16 h-16 text-green-500 mx-auto" />
          <h2 className="text-2xl font-bold">Enhorabona, {player.name}!</h2>
          <p className="text-xl text-muted-foreground">Has acabat amb <span className="text-accent font-black">{formatMoney(player.money)}</span></p>
        </div>
        <div className="fixed bottom-4 right-4 text-white/60 text-xs opacity-60">Developed by Walid Rabbou</div>
      </div>
    );
  }

  const handleBet = (idx: number, amount: number) => {
    if (hasConfirmed || showResult) return;
    const current = localBets[idx.toString()] || 0;
    const newVal = Math.max(0, current + amount);
    if (newVal > current && remainingMoney < (newVal - current)) return;
    setLocalBets({ ...localBets, [idx.toString()]: newVal });
  };

  const startReveal = () => {
    setIsRevealing(true);
    let count = 3;
    const interval = setInterval(() => {
      count--;
      setCountdown(count);
      if (count === 0) {
        clearInterval(interval);
        setShowResult(true);
        setIsRevealing(false);
      }
    }, 1000);
  };

  const canConfirm = remainingMoney === 0 && Object.values(localBets).some(v => v === 0);
  
  const getRuleText = () => {
    const q = player.questionNumber;
    if (q <= 3) return "📋 Tens 4 opcions. Reparteix els diners en un màxim de 3 respostes. Una ha de quedar buida.";
    if (q <= 7) return "📋 Tens 3 opcions. Reparteix els diners en un màxim de 2 respostes. Una ha de quedar buida.";
    return "📋 FINAL: 2 opcions. Tot o res. Has de posar tots els diners en UNA sola opció.";
  };

  return (
    <div className="min-h-screen bg-black text-white p-4 pb-24 relative flex flex-col overflow-x-hidden">
      <header className="flex justify-between items-center mb-6 bg-white/5 p-4 rounded-xl border border-white/10">
        <div className="flex flex-col text-left"><span className="text-xs uppercase text-muted-foreground tracking-widest">Pregunta {player.questionNumber} de {player.totalQuestions}</span><span className="text-2xl font-black text-primary uppercase">{player.name}</span></div>
        <div className="flex flex-col items-end"><span className="text-xs uppercase text-muted-foreground tracking-widest">Balance Actual</span><span className="text-2xl font-black text-accent">{formatMoney(totalMoney)}</span></div>
      </header>

      <main className="flex-1 space-y-6 max-w-2xl mx-auto w-full">
        <div className="bg-white/5 p-8 rounded-3xl border border-white/10 text-center shadow-2xl"><h2 className="text-2xl md:text-4xl font-bold leading-tight">{currentQuestion.text}</h2></div>
        <div className="bg-blue-900/10 border border-blue-500/20 p-4 rounded-xl text-xs text-blue-200/70 text-center font-medium uppercase tracking-wider">{getRuleText()}</div>

        <div className="space-y-4">
          <div className="text-center font-mono text-sm text-muted-foreground mb-4 uppercase tracking-[0.2em]">Diners Disponibles: <span className={cn("font-bold text-xl", remainingMoney === 0 ? "text-green-500" : "text-accent")}>{formatMoney(remainingMoney)}</span></div>
          {currentQuestion.options.map((opt, i) => {
            const bet = localBets[i.toString()] || 0;
            const isCorrect = i === currentQuestion.correctIndex;
            const isSelected = bet > 0;
            
            return (
              <div key={i} className={cn(
                "p-5 rounded-3xl border-2 transition-all relative overflow-hidden",
                showResult 
                  ? (isCorrect ? "border-green-500 bg-green-500/20 shadow-[0_0_30px_rgba(34,197,94,0.4)] scale-[1.02]" : "border-red-500/30 bg-red-500/10 opacity-40") 
                  : (isSelected ? "border-accent bg-accent/5" : "border-white/10 bg-white/5")
              )}>
                <div className="flex justify-between items-center gap-4 relative z-10">
                  <div className="flex items-center gap-4 flex-1">
                    <span className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center font-black text-lg shadow-inner">{['A','B','C','D'][i]}</span>
                    <span className="text-lg md:text-xl font-bold">{opt}</span>
                  </div>
                  
                  {!hasConfirmed && (
                    <div className="flex items-center gap-2">
                      <Button variant="ghost" size="icon" className="h-12 w-12 bg-white/5 border border-white/10 rounded-xl hover:bg-white/10" disabled={bet <= 0} onClick={() => handleBet(i, -50000)}>-</Button>
                      <div className={cn("min-w-[140px] text-center font-mono font-black text-xl transition-colors", bet > 0 ? "text-accent" : "text-white/20")}>{formatMoney(bet)}</div>
                      <Button variant="ghost" size="icon" className="h-12 w-12 bg-white/5 border border-white/10 rounded-xl hover:bg-white/10" disabled={remainingMoney < 50000} onClick={() => handleBet(i, 50000)}>+</Button>
                    </div>
                  )}
                  {hasConfirmed && (
                     <div className={cn("font-mono font-black text-xl", bet > 0 ? "text-accent" : "text-white/20")}>{formatMoney(bet)}</div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </main>

      <div className="fixed bottom-0 left-0 right-0 p-4 bg-black/95 backdrop-blur-2xl border-t border-white/10 z-40 shadow-[0_-20px_50px_rgba(0,0,0,0.5)]">
        <div className="max-w-2xl mx-auto">
          {!hasConfirmed && (
            <Button size="lg" className={cn("w-full h-20 text-2xl font-display uppercase tracking-widest transition-all rounded-2xl", canConfirm ? "bg-primary text-white shadow-[0_0_30px_rgba(14,165,233,0.3)]" : "bg-white/5 text-white/20 cursor-not-allowed")} disabled={!canConfirm} onClick={() => setHasConfirmed(true)}>Confirmar Resposta</Button>
          )}
          
          {hasConfirmed && !isRevealing && !showResult && (
            <Button size="lg" className="w-full h-20 text-2xl font-display uppercase tracking-widest bg-accent text-black hover:bg-accent/90 rounded-2xl shadow-[0_0_30px_rgba(234,179,8,0.3)]" onClick={startReveal}>Revelar Resultat</Button>
          )}

          {isRevealing && (
            <div className="w-full h-20 flex items-center justify-center text-5xl font-black text-accent animate-pulse uppercase tracking-[0.5em]">{countdown}</div>
          )}

          {showResult && (
            <div className="space-y-4 animate-in fade-in slide-in-from-bottom-4 duration-500">
              <div className="text-center">
                {localBets[currentQuestion.correctIndex.toString()] > 0 ? (
                  <div className="text-green-500 font-black text-3xl uppercase tracking-widest drop-shadow-[0_0_15px_rgba(34,197,94,0.5)]">✅ CORRECTE! Nou balance: {formatMoney(localBets[currentQuestion.correctIndex.toString()])}</div>
                ) : (
                  <div className="text-red-500 font-black text-3xl uppercase tracking-widest drop-shadow-[0_0_15px_rgba(239,68,68,0.5)]">❌ ELIMINAT!</div>
                )}
              </div>
              <Button size="lg" className="w-full h-20 text-2xl font-display uppercase bg-blue-600 hover:bg-blue-500 rounded-2xl shadow-xl" onClick={() => submitAnswer(localBets)}>Següent Pregunta</Button>
            </div>
          )}
        </div>
      </div>

      <div className="fixed bottom-4 right-4 text-white/60 text-xs opacity-60 pointer-events-none uppercase tracking-tighter">Developed by Walid Rabbou</div>
    </div>
  );
}
