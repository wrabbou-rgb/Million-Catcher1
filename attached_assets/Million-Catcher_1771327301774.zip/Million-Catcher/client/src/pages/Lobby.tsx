import { useState } from 'react';
import { useGame } from '@/hooks/use-game';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Play, Users, Smartphone, Loader2 } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export default function Lobby() {
  const { joinGame, isConnected, gameState, playerId } = useGame();
  const [name, setName] = useState('');
  const [code, setCode] = useState('');

  const handleSubmit = (e: React.FormEvent) => { e.preventDefault(); if (name && code) joinGame(name, code.toUpperCase()); };

  const player = gameState?.players.find(p => p.id === playerId);

  return (
    <div className="min-h-screen bg-black flex items-center justify-center p-4 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-blue-900/20 via-black to-blue-900/20" />
      <AnimatePresence mode="wait">
        {!player ? (
          <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 1.05 }} className="w-full max-w-md z-10">
            <Card className="bg-white/5 border-white/10 backdrop-blur-xl">
              <CardHeader className="text-center space-y-2">
                <div className="w-16 h-16 bg-blue-600/20 rounded-2xl flex items-center justify-center mx-auto mb-4 border border-blue-500/20"><Smartphone className="w-8 h-8 text-blue-400" /></div>
                <CardTitle className="text-3xl font-display uppercase text-white">Entrar a la <span className="text-accent">Partida</span></CardTitle>
                <CardDescription className="text-blue-200/50">Introdueix el teu nom i el codi que veus a la pantalla.</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="space-y-2"><label className="text-white/70 ml-1">Com et dius?</label><Input placeholder="El teu nom..." value={name} onChange={(e) => setName(e.target.value)} className="bg-white/5 border-white/10 text-white h-12" maxLength={15} required /></div>
                  <div className="space-y-2"><label className="text-white/70 ml-1">Codi de partida</label><Input placeholder="EX: 123456" value={code} onChange={(e) => setCode(e.target.value.toUpperCase())} className="bg-white/5 border-white/10 text-white h-12 text-center text-2xl font-black tracking-widest" maxLength={6} required /></div>
                  <Button type="submit" className="w-full h-14 text-xl font-display uppercase bg-blue-600 hover:bg-blue-500" disabled={!isConnected}>{isConnected ? "Entrar al Joc" : <><Loader2 className="mr-2 h-5 w-5 animate-spin" /> Connectant...</>}</Button>
                </form>
              </CardContent>
            </Card>
          </motion.div>
        ) : (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center space-y-8 z-10">
            <div className="relative"><div className="w-32 h-32 border-4 border-blue-500/20 border-t-accent rounded-full animate-spin mx-auto" /><div className="absolute inset-0 flex items-center justify-center"><Smartphone className="w-12 h-12 text-blue-400 animate-pulse" /></div></div>
            <div className="space-y-2"><h2 className="text-4xl font-display text-white uppercase tracking-tight">Preparat, <span className="text-accent">{player.name}</span>!</h2><p className="text-xl text-blue-200/60 font-light">Esperant que el presentador comenci la partida...</p></div>
            <div className="bg-white/5 border border-white/10 rounded-2xl p-6 backdrop-blur max-w-xs mx-auto"><div className="text-sm text-white/30 uppercase tracking-widest mb-2">Jugadors a la sala</div><div className="text-3xl font-bold text-white">{gameState?.players.length}/{gameState?.maxPlayers}</div></div>
          </motion.div>
        )}
      </AnimatePresence>
      <div className="fixed bottom-4 right-4 text-white/60 text-xs opacity-60">Developed by Walid Rabbou</div>
    </div>
  );
}
