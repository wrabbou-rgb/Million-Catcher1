import { useGame } from '@/hooks/use-game';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Users, Trophy, Tv, Copy } from 'lucide-react';
import { cn } from '@/lib/utils';
import { motion } from 'framer-motion';
import { useToast } from '@/hooks/use-toast';

const formatMoney = (amount: number) => {
  return new Intl.NumberFormat('es-ES', { style: 'currency', currency: 'EUR', maximumFractionDigits: 0 }).format(amount).replace(/\s/g, '.').replace('€', ' €');
};

export default function HostScreen() {
  const { gameState, hostAction, createRoom, isConnected } = useGame();
  const { toast } = useToast();

  if (!gameState) return <div className="min-h-screen bg-black flex items-center justify-center"><div className="animate-spin w-12 h-12 border-4 border-primary border-t-transparent rounded-full" /></div>;

  const copyCode = () => { if (gameState.code) { navigator.clipboard.writeText(gameState.code); toast({ title: "Codi copiat!" }); } };

  if (gameState.phase === 'setup') {
    return (
      <div className="min-h-screen flex items-center justify-center p-4 bg-black relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-blue-900/20 via-black to-blue-900/20" />
        <Card className="bg-white/5 border-white/10 backdrop-blur-xl w-full max-w-md p-8 text-center space-y-6 shadow-2xl">
          <Tv className="w-16 h-16 text-accent mx-auto animate-pulse" />
          <h1 className="text-3xl font-display uppercase text-white tracking-widest">Configurar <span className="text-accent">Sala</span></h1>
          <form onSubmit={(e) => { e.preventDefault(); const formData = new FormData(e.currentTarget); createRoom(formData.get('hostName') as string, parseInt(formData.get('maxPlayers') as string)); }} className="space-y-4 text-left">
            <div className="space-y-2"><label className="text-white/70 text-xs uppercase tracking-widest font-bold">Nom del Host</label><input name="hostName" placeholder="Ex: Professor" className="w-full bg-white/5 border border-white/10 rounded-xl h-14 px-4 text-white focus:border-accent outline-none transition-all" required /></div>
            <div className="space-y-2"><label className="text-white/70 text-xs uppercase tracking-widest font-bold">Màxim Jugadors</label><input name="maxPlayers" type="number" min="2" max="30" defaultValue="10" className="w-full bg-white/5 border border-white/10 rounded-xl h-14 px-4 text-white focus:border-accent outline-none transition-all" required /></div>
            <Button type="submit" className="w-full h-16 text-xl font-display uppercase bg-accent text-black hover:bg-accent/90 rounded-xl shadow-lg shadow-accent/20" disabled={!isConnected}>Crear Sala</Button>
          </form>
        </Card>
        <div className="fixed bottom-4 right-4 text-white/60 text-xs opacity-60">Developed by Walid Rabbou</div>
      </div>
    );
  }

  const sortedPlayers = [...gameState.players].sort((a, b) => b.money - a.money);

  if (gameState.phase === 'podium') {
    const topPlayers = sortedPlayers.slice(0, 3);
    return (
      <div className="min-h-screen bg-black text-white p-8 flex flex-col items-center justify-center relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-blue-900/40 via-black to-black -z-10" />
        <h1 className="text-7xl font-display uppercase text-accent mb-20 animate-bounce tracking-tighter drop-shadow-[0_0_30px_rgba(234,179,8,0.5)]">Podi Final</h1>
        <div className="flex items-end gap-12 h-96">
          {topPlayers[1] && <div className="flex flex-col items-center"><div className="text-3xl font-bold mb-4">🥈 {topPlayers[1].name}</div><div className="w-56 bg-slate-400/10 border-t-8 border-slate-400 h-56 flex flex-col items-center justify-center rounded-t-3xl shadow-2xl backdrop-blur-sm"><div className="text-5xl font-black mb-2">2n</div><div className="text-2xl text-slate-300 font-mono">{formatMoney(topPlayers[1].money)}</div></div></div>}
          {topPlayers[0] && <div className="flex flex-col items-center"><div className="text-5xl font-black mb-6 text-accent drop-shadow-xl">🥇 {topPlayers[0].name}</div><div className="w-64 bg-accent/10 border-t-[12px] border-accent h-72 flex flex-col items-center justify-center rounded-t-3xl shadow-[0_-20px_60px_rgba(234,179,8,0.3)] backdrop-blur-md"><div className="text-7xl font-black text-accent mb-2">1r</div><div className="text-3xl font-black font-mono">{formatMoney(topPlayers[0].money)}</div></div></div>}
          {topPlayers[2] && <div className="flex flex-col items-center"><div className="text-2xl font-bold mb-4">🥉 {topPlayers[2].name}</div><div className="w-48 bg-amber-800/10 border-t-8 border-amber-800 h-40 flex flex-col items-center justify-center rounded-t-3xl shadow-2xl backdrop-blur-sm"><div className="text-4xl font-black mb-2">3r</div><div className="text-xl text-amber-600 font-mono">{formatMoney(topPlayers[2].money)}</div></div></div>}
        </div>
        <div className="fixed bottom-4 right-4 text-white/60 text-xs opacity-60">Developed by Walid Rabbou</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black text-white p-8 overflow-hidden relative flex flex-col">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-blue-900/40 via-black to-black -z-10" />
      <header className="flex justify-between items-start mb-16 px-4">
        <div className="space-y-4">
          <h1 className="text-4xl font-display text-white/40 uppercase tracking-[0.2em]">Codi de la Sala</h1>
          <div className="text-9xl font-black text-primary tracking-widest drop-shadow-[0_0_40px_rgba(14,165,233,0.6)] cursor-pointer flex items-center gap-6 group" onClick={copyCode}>
            {gameState.code} <Copy className="w-12 h-12 opacity-10 group-hover:opacity-100 transition-all duration-300" />
          </div>
        </div>
        <div className="text-right space-y-2 bg-white/5 p-8 rounded-3xl border border-white/10 backdrop-blur-md">
          <div className="text-sm uppercase tracking-[0.3em] text-muted-foreground font-bold">Jugadors Connectats</div>
          <div className="text-7xl font-display font-black text-white">{gameState.players.length}<span className="text-4xl text-white/10 ml-2">/{gameState.maxPlayers}</span></div>
        </div>
      </header>

      <main className="flex-1 grid grid-cols-2 gap-12 min-h-0 px-4">
        <Card className="bg-white/5 border-white/10 p-8 flex flex-col min-h-0 rounded-[2.5rem] shadow-2xl backdrop-blur-sm">
          <h3 className="text-2xl font-display text-white/60 uppercase tracking-[0.2em] mb-10 flex items-center gap-4"><Users className="w-8 h-8 text-primary" /> Estat dels Jugadors</h3>
          <div className="space-y-4 overflow-y-auto pr-4 custom-scrollbar flex-1">
            {gameState.players.map((p) => (
              <div key={p.id} className={cn("p-6 rounded-[1.5rem] border-2 bg-white/5 border-white/5 flex justify-between items-center transition-all duration-500", p.isEliminated && "opacity-30 grayscale blur-[1px]")}>
                <div className="flex flex-col gap-1">
                  <span className="font-black text-2xl uppercase tracking-tighter">{p.name}</span>
                  <span className="text-xs text-white/30 uppercase font-black tracking-widest bg-white/5 px-3 py-1 rounded-full w-fit">
                    {p.isEliminated ? "❌ Eliminat" : p.hasFinished ? "✅ Finalitzat" : `Pregunta ${p.questionNumber} de ${p.totalQuestions}`}
                  </span>
                </div>
                <div className="text-right flex flex-col gap-1">
                  <span className="text-3xl font-black text-accent font-mono tracking-tighter">{formatMoney(p.money)}</span>
                  <span className="text-[10px] text-white/20 uppercase font-black tracking-[0.2em]">Saldo Individual</span>
                </div>
              </div>
            ))}
            {gameState.players.length === 0 && <div className="h-full flex flex-col items-center justify-center text-white/10 gap-8 opacity-50"><Users className="w-32 h-32 animate-pulse" /><p className="font-display text-2xl uppercase tracking-[0.5em]">Esperant jugadors...</p></div>}
          </div>
        </Card>

        <Card className="bg-white/5 border-white/10 p-8 flex flex-col min-h-0 rounded-[2.5rem] shadow-2xl backdrop-blur-sm">
          <h3 className="text-2xl font-display text-white/60 uppercase tracking-[0.2em] mb-10 flex items-center gap-4"><Trophy className="w-8 h-8 text-accent" /> Classificació en Directe</h3>
          <div className="space-y-4 overflow-y-auto pr-4 custom-scrollbar flex-1">
            {sortedPlayers.map((p, idx) => (
              <motion.div key={p.id} layout className={cn("p-6 rounded-[1.5rem] border-2 bg-white/10 border-white/5 flex justify-between items-center shadow-xl", p.isEliminated && "opacity-30 grayscale blur-[1px]")}>
                <div className="flex items-center gap-6">
                  <div className={cn("w-12 h-12 rounded-full flex items-center justify-center font-black text-2xl shadow-2xl", idx === 0 ? "bg-accent text-black scale-110" : "bg-white/5 text-white/30")}>{idx + 1}</div>
                  <span className="font-black text-2xl uppercase tracking-tighter">{p.name}</span>
                </div>
                <span className="text-3xl font-black text-accent font-mono tracking-tighter">{formatMoney(p.money)}</span>
              </motion.div>
            ))}
          </div>
        </Card>
      </main>

      {gameState.phase === 'lobby' && gameState.players.length > 0 && (
        <div className="mt-12 px-4">
          <Button onClick={() => hostAction('start_game')} className="w-full h-24 text-4xl font-display bg-green-600 hover:bg-green-500 shadow-[0_0_50px_rgba(22,163,74,0.4)] uppercase tracking-[0.3em] rounded-[2rem] transition-all duration-300 active:scale-95">Començar Partida</Button>
        </div>
      )}

      <div className="fixed bottom-6 right-8 text-white/40 text-sm opacity-40 uppercase tracking-[0.2em] font-black">Developed by Walid Rabbou</div>
    </div>
  );
}
