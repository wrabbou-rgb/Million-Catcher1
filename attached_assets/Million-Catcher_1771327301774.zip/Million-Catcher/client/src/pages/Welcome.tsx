import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { Tv, Smartphone } from "lucide-react";

export default function Welcome() {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4 relative overflow-hidden">
      {/* Background glow effects */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-blue-600/20 rounded-full blur-[100px] -z-10" />
      
      <motion.div 
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.8 }}
        className="text-center space-y-12 max-w-4xl z-10"
      >
        <div className="space-y-4">
          <h1 className="text-6xl md:text-8xl font-display uppercase tracking-tighter text-transparent bg-clip-text bg-gradient-to-b from-white to-blue-200 drop-shadow-2xl">
            Atrapa un<br />
            <span className="text-accent drop-shadow-[0_0_25px_rgba(234,179,8,0.5)]">Milió</span>
          </h1>
          <p className="text-xl md:text-2xl text-blue-200/80 font-light max-w-2xl mx-auto">
            Posa a prova els teus coneixements i mantingues la sang freda per guanyar el premi gros.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 w-full">
          <Link href="/lobby" className="group">
            <div className="h-full bg-white/5 hover:bg-white/10 border border-white/10 hover:border-accent/50 rounded-2xl p-8 transition-all duration-300 transform hover:-translate-y-2 cursor-pointer flex flex-col items-center gap-6">
              <div className="w-20 h-20 rounded-full bg-blue-600/20 flex items-center justify-center group-hover:bg-blue-600/40 transition-colors">
                <Smartphone className="w-10 h-10 text-blue-400 group-hover:text-white" />
              </div>
              <div className="space-y-2">
                <h3 className="text-2xl font-bold text-white">Sóc Jugador</h3>
                <p className="text-sm text-white/50">Uneix-te a una partida des del teu mòbil o ordinador.</p>
              </div>
              <Button className="w-full mt-auto bg-blue-600 hover:bg-blue-500 font-display uppercase tracking-widest">
                Jugar Ara
              </Button>
            </div>
          </Link>

          <Link href="/host" className="group">
            <div className="h-full bg-white/5 hover:bg-white/10 border border-white/10 hover:border-accent/50 rounded-2xl p-8 transition-all duration-300 transform hover:-translate-y-2 cursor-pointer flex flex-col items-center gap-6">
              <div className="w-20 h-20 rounded-full bg-accent/20 flex items-center justify-center group-hover:bg-accent/40 transition-colors">
                <Tv className="w-10 h-10 text-accent group-hover:text-white" />
              </div>
              <div className="space-y-2">
                <h3 className="text-2xl font-bold text-white">Sóc Presentador</h3>
                <p className="text-sm text-white/50">Crea una sala i mostra el joc a la pantalla gran.</p>
              </div>
              <Button variant="outline" className="w-full mt-auto border-accent text-accent hover:bg-accent hover:text-black font-display uppercase tracking-widest">
                Crear Sala
              </Button>
            </div>
          </Link>
        </div>
      </motion.div>
      
      <footer className="absolute bottom-8 text-white/20 text-sm right-8 opacity-60">
        Developed by Walid Rabbou
      </footer>
    </div>
  );
}
