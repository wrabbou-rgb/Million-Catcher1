import { motion } from 'framer-motion';

interface MoneyBundleProps {
  amount: number;
  index: number;
}

export function MoneyBundle({ amount, index }: MoneyBundleProps) {
  // Visual representation of a stack of cash
  // Staggered slightly based on index for a "piled up" look
  const randomRotation = (index % 5 - 2) * 2; // -4 to +4 degrees
  const randomOffset = (index % 3 - 1) * 2;   // -2 to +2 px

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.5, y: -20 }}
      animate={{ opacity: 1, scale: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.5, y: 50 }}
      transition={{ duration: 0.3, delay: index * 0.05 }}
      style={{ rotate: randomRotation, x: randomOffset }}
      className="relative flex items-center justify-center w-24 h-12 bg-green-800 border-2 border-green-400 rounded-md shadow-lg"
    >
      <div className="absolute inset-x-0 h-2 bg-white/20 top-2" />
      <span className="text-xs font-bold text-green-100 font-mono tracking-widest drop-shadow-sm">
        {(amount / 1000).toFixed(0)}k€
      </span>
      <div className="absolute w-full h-1 bg-black/30 bottom-0" />
    </motion.div>
  );
}

interface MoneyDisplayProps {
  total: number;
  compact?: boolean;
}

export function MoneyDisplay({ total, compact = false }: MoneyDisplayProps) {
  // Formats large numbers cleanly: 1.000.000 €
  const formatted = new Intl.NumberFormat('es-ES', {
    style: 'currency',
    currency: 'EUR',
    maximumFractionDigits: 0
  }).format(total);

  if (compact) {
    return (
      <div className="flex items-center gap-2 bg-black/40 px-4 py-2 rounded-full border border-accent/30">
        <span className="text-accent font-bold font-mono text-lg md:text-xl">{formatted}</span>
      </div>
    );
  }

  return (
    <div className="flex flex-col items-center">
      <div className="text-sm uppercase tracking-widest text-muted-foreground mb-1">Diners actuals</div>
      <div className="text-4xl md:text-5xl font-black text-accent font-display drop-shadow-[0_0_15px_rgba(234,179,8,0.3)]">
        {formatted}
      </div>
    </div>
  );
}
