import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';
import { Slot } from '@radix-ui/react-slot';
import { AlertTriangle, CheckCircle2, XCircle } from 'lucide-react';

interface OptionCardProps {
  index: number;
  text: string;
  betAmount?: number;
  isCorrect?: boolean | null; // null = unknown, true = correct, false = incorrect
  isEliminated?: boolean;
  disabled?: boolean;
  maxBet?: boolean; // If this option has the max possible bet or simply has bets
  onAddBet?: () => void;
  onRemoveBet?: () => void;
  onMaxBet?: () => void;
  phase?: 'betting' | 'result' | 'question';
  totalMoney?: number;
}

const LETTERS = ['A', 'B', 'C', 'D'];
const COLORS = [
  'bg-blue-600 border-blue-400 text-blue-50',
  'bg-pink-600 border-pink-400 text-pink-50',
  'bg-yellow-600 border-yellow-400 text-yellow-50',
  'bg-green-600 border-green-400 text-green-50'
];

export function OptionCard({
  index,
  text,
  betAmount = 0,
  isCorrect = null,
  disabled = false,
  onAddBet,
  onRemoveBet,
  onMaxBet,
  phase = 'question',
  totalMoney = 0
}: OptionCardProps) {
  const isTrapdoorOpen = phase === 'result' && isCorrect === false;
  const isWinning = phase === 'result' && isCorrect === true;

  return (
    <div className="relative group w-full">
      {/* Trapdoor Mechanism Visuals */}
      <div className={cn(
        "absolute -inset-2 rounded-xl bg-black/50 blur-sm transition-opacity",
        isTrapdoorOpen ? "opacity-100" : "opacity-0"
      )} />

      <motion.div
        className={cn(
          "relative flex flex-col rounded-xl overflow-hidden border-b-4 transition-all duration-300",
          COLORS[index % COLORS.length],
          isTrapdoorOpen && "translate-y-[100%] rotate-x-90 opacity-0", // Trapdoor animation
          isWinning && "ring-4 ring-white scale-105 z-10 shadow-[0_0_30px_rgba(255,255,255,0.4)]",
          disabled && !isWinning && !isTrapdoorOpen && "opacity-80 grayscale-[0.5]",
          "h-full min-h-[180px]"
        )}
        animate={isTrapdoorOpen ? { y: 200, opacity: 0, scale: 0.8 } : { y: 0, opacity: 1, scale: 1 }}
        transition={{ duration: 0.8, ease: "anticipate" }}
      >
        {/* Header (Letter) */}
        <div className="bg-black/20 p-3 flex justify-between items-center">
          <span className="font-display text-2xl font-bold">{LETTERS[index]}</span>
          {phase === 'result' && isCorrect !== null && (
            isCorrect ? <CheckCircle2 className="w-6 h-6 text-white" /> : <XCircle className="w-6 h-6 text-black/50" />
          )}
        </div>

        {/* Content (Text) */}
        <div className="flex-1 p-4 flex items-center justify-center text-center">
          <p className="text-lg md:text-xl font-bold leading-tight">{text}</p>
        </div>

        {/* Betting Controls (Only visible in betting phase) */}
        {phase === 'betting' && !disabled && (
          <div className="bg-black/30 p-2 grid grid-cols-3 gap-2">
            <button
              onClick={onRemoveBet}
              className="bg-red-500/20 hover:bg-red-500/40 text-white rounded p-2 font-bold transition-colors"
            >
              -25k
            </button>
            <div className="flex flex-col items-center justify-center">
              <span className="text-xs opacity-70">APOSTA</span>
              <span className="font-mono font-bold text-accent">{(betAmount / 1000)}k</span>
            </div>
            <button
              onClick={onAddBet}
              className="bg-green-500/20 hover:bg-green-500/40 text-white rounded p-2 font-bold transition-colors"
            >
              +25k
            </button>
            <button 
              onClick={onMaxBet}
              className="col-span-3 text-xs bg-white/10 hover:bg-white/20 rounded py-1 mt-1 font-semibold uppercase tracking-wider"
            >
              Tot el restant
            </button>
          </div>
        )}

        {/* Amount Display (Visible in other phases if bet > 0) */}
        {phase !== 'betting' && betAmount > 0 && (
          <div className="bg-black/40 p-3 flex justify-center items-center gap-2">
            <div className="w-3 h-3 bg-accent rounded-full animate-pulse" />
            <span className="font-mono font-bold text-accent text-lg">
              {new Intl.NumberFormat('es-ES', { style: 'currency', currency: 'EUR', maximumFractionDigits: 0 }).format(betAmount)}
            </span>
          </div>
        )}
        
        {/* Trapdoor Hole (Visual only, behind the card) */}
        {isTrapdoorOpen && (
          <div className="absolute inset-0 bg-black flex items-center justify-center">
             <span className="text-red-600 font-display text-4xl opacity-50">ELIMINAT</span>
          </div>
        )}
      </motion.div>
    </div>
  );
}
