import { useEffect, useState } from 'react';
import { io, Socket } from 'socket.io-client';
import { useToast } from './use-toast';

export type Player = {
  id: string;
  name: string;
  money: number;
  isEliminated: boolean;
  questionNumber: number;
  totalQuestions: number;
  hasFinished: boolean;
};

export type Question = {
  text: string;
  options: string[];
  maxOptionsToBet: number;
  correctIndex: number;
};

export type GameState = {
  phase: 'setup' | 'lobby' | 'active' | 'podium';
  players: Player[];
  code: string;
  maxPlayers: number;
  hostName: string;
};

let socketInstance: Socket | null = null;

export function useGame() {
  const [gameState, setGameState] = useState<GameState | null>(null);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [isConnected, setIsConnected] = useState(false);
  const [playerId, setPlayerId] = useState<string | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    if (!socketInstance) {
      socketInstance = io(window.location.origin, {
        reconnectionAttempts: 5,
        transports: ['websocket'],
      });
    }

    const socket = socketInstance;

    function onConnect() {
      setIsConnected(true);
      setPlayerId(socket.id || null);
    }

    function onDisconnect() {
      setIsConnected(false);
    }

    function onGameState(newState: GameState) {
      setGameState(newState);
    }

    function onQuestions(newQuestions: Question[]) {
      setQuestions(newQuestions);
    }

    function onError(error: { message: string }) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    }

    socket.on('connect', onConnect);
    socket.on('disconnect', onDisconnect);
    socket.on('gameState', onGameState);
    socket.on('questions', onQuestions);
    socket.on('error', onError);

    return () => {
      socket.off('connect', onConnect);
      socket.off('disconnect', onDisconnect);
      socket.off('gameState', onGameState);
      socket.off('questions', onQuestions);
      socket.off('error', onError);
    };
  }, [toast, playerId]);

  const createRoom = (hostName: string, maxPlayers: number) => {
    socketInstance?.emit('createRoom', { hostName, maxPlayers });
  };

  const joinGame = (name: string, code: string) => {
    socketInstance?.emit('join', { name, code });
  };

  const submitAnswer = (bets: Record<string, number>) => {
    socketInstance?.emit('playerProgress', { type: 'answer', bets });
  };

  const hostAction = (action: 'start_game') => {
    socketInstance?.emit('hostAction', { action });
  };

  return {
    socket: socketInstance,
    gameState,
    questions,
    playerId,
    isConnected,
    createRoom,
    joinGame,
    submitAnswer,
    hostAction,
  };
}
