## Packages
socket.io-client | Real-time communication with the game server
framer-motion | Smooth animations for money drops and transitions
clsx | Utility for conditional classes
tailwind-merge | Utility for merging tailwind classes

## Notes
Socket.IO connects to window.location.origin
Game logic is handled via WebSocket events
Catalan language is required for all text
