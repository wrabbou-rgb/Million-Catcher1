
import { Question } from "@shared/schema";

export interface IStorage {
  // In-memory game state management
  getQuestions(): Question[];
}

export class MemStorage implements IStorage {
  private questions: Question[] = [
    {
      id: 1,
      text: "Quin any va inventar Nikolaus August Otto el primer motor de quatre temps amb compressió?",
      options: ["1876", "1886", "1867", "1890"],
      correctIndex: 0, // 1876
      maxoptionsToBet: 3
    },
    {
      id: 2,
      text: "Quin és el component que transforma el moviment rectilini del pistó en moviment rotatiu?",
      options: ["La biela", "El cigonyal", "L'arbre de lleves", "El volant d'inèrcia"],
      correctIndex: 1, // El cigonyal
      maxoptionsToBet: 3
    },
    {
      id: 3,
      text: "En quin ordre es produeixen les fases del motor de 4 temps?",
      options: ["Admissió, explosió, compressió, escapament", "Compressió, admissió, explosió, escapament", "Admissió, compressió, explosió, escapament", "Admissió, compressió, escapament, explosió"],
      correctIndex: 2, // Admissió, compressió, explosió, escapament
      maxoptionsToBet: 3
    },
    {
      id: 4,
      text: "Quina temperatura pot superar la combustió dins del cilindre?",
      options: ["1.000 °C", "2.000 °C", "3.000 °C"],
      correctIndex: 1, // 2.000 °C
      maxoptionsToBet: 2
    },
    {
      id: 5,
      text: "Què és el càrter en un motor Otto?",
      options: ["La part superior del cilindre", "El dipòsit d'oli a la part inferior del motor", "El conducte d'admissió"],
      correctIndex: 1, // El dipòsit d'oli a la part inferior del motor
      maxoptionsToBet: 2
    },
    {
      id: 6,
      text: "Segons el Segon Principi de la Termodinàmica aplicat al motor:",
      options: ["Tota la calor es transforma en treball", "Part de l'energia s'ha de cedir a un focus fred", "El rendiment pot ser del 100%"],
      correctIndex: 1, // Part de l'energia s'ha de cedir a un focus fred
      maxoptionsToBet: 2
    },
    {
      id: 7,
      text: "Quina diferència principal té el motor de 2 temps respecte al de 4 temps?",
      options: ["Té més vàlvules", "Completa el cicle en una volta de cigonyal", "Funciona només amb gasoil"],
      correctIndex: 1, // Completa el cicle en una volta de cigonyal
      maxoptionsToBet: 2
    },
    {
      id: 8,
      text: "Quina és la temperatura de treball òptima d'un motor Otto?",
      options: ["90 °C", "150 °C"],
      correctIndex: 0, // 90 °C
      maxoptionsToBet: 1 // Todo o nada
    }
  ];

  getQuestions(): Question[] {
    return this.questions;
  }
}

export const storage = new MemStorage();
