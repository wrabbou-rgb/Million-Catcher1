import type { Express } from "express";
import { createServer, type Server } from "http";
import { Server as SocketIOServer } from "socket.io";
import { storage } from "./storage";
import { joinGameSchema, betSchema, createRoomSchema } from "@shared/schema";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  const io = new SocketIOServer(httpServer, {
    path: "/socket.io",
    cors: {
      origin: "*",
    },
  });

  let gameCode = Math.random().toString(36).substring(2, 8).toUpperCase();
  let gameState = {
    phase: 'setup', 
    players: {} as Record<string, { 
      id: string; 
      name: string; 
      money: number; 
      isEliminated: boolean; 
      currentQuestionIndex: number;
      hasFinished: boolean;
    }>,
    maxPlayers: 30,
    hostName: "",
  };

  function broadcastState() {
    const questions = storage.getQuestions();
    const publicState = {
      phase: gameState.phase,
      players: Object.values(gameState.players).map(p => ({
        id: p.id,
        name: p.name,
        money: p.money,
        isEliminated: p.isEliminated,
        questionNumber: p.currentQuestionIndex + 1,
        totalQuestions: questions.length,
        hasFinished: p.hasFinished
      })),
      code: gameCode,
      maxPlayers: gameState.maxPlayers,
      hostName: gameState.hostName
    };

    io.emit('gameState', publicState);
  }

  io.on("connection", (socket) => {
    socket.emit('gameState', {
      phase: gameState.phase,
      code: gameCode,
      maxPlayers: gameState.maxPlayers,
      hostName: gameState.hostName,
      questions: storage.getQuestions().map(q => ({ text: q.text, options: q.options, maxOptionsToBet: q.maxoptionsToBet })),
      players: Object.values(gameState.players).map(p => ({ id: p.id, name: p.name, money: p.money, isEliminated: p.isEliminated, questionNumber: p.currentQuestionIndex + 1 }))
    });

    socket.on("createRoom", (data) => {
      const result = createRoomSchema.safeParse(data);
      if (!result.success) return socket.emit("error", { message: "Dades invàlides" });
      gameState.hostName = result.data.hostName;
      gameState.maxPlayers = result.data.maxPlayers;
      gameState.phase = 'lobby';
      broadcastState();
    });

    socket.on("join", (data) => {
      const result = joinGameSchema.safeParse(data);
      if (!result.success) return socket.emit("error", { message: "Dades invàlides" });
      if (result.data.code !== gameCode) return socket.emit("error", { message: "Codi incorrecte" });
      if (gameState.phase !== 'lobby' && gameState.phase !== 'active') return socket.emit("error", { message: "La partida no està en fase d'inscripció" });
      if (Object.keys(gameState.players).length >= gameState.maxPlayers) return socket.emit("error", { message: "La sala està plena" });

      gameState.players[socket.id] = { 
        id: socket.id, 
        name: result.data.name, 
        money: 1000000, 
        isEliminated: false, 
        currentQuestionIndex: 0,
        hasFinished: false
      };
      
      socket.emit('questions', storage.getQuestions().map(q => ({ 
        text: q.text, 
        options: q.options, 
        maxOptionsToBet: q.maxoptionsToBet,
        correctIndex: q.correctIndex 
      })));
      broadcastState();
    });

    socket.on("playerProgress", (data) => {
      const player = gameState.players[socket.id];
      if (!player || player.isEliminated || player.hasFinished) return;

      if (data.type === 'answer') {
        const questions = storage.getQuestions();
        const currentQ = questions[player.currentQuestionIndex];
        const correctIndex = currentQ.correctIndex;
        const betOnCorrect = data.bets[correctIndex.toString()] || 0;
        
        player.money = betOnCorrect;
        if (player.money === 0) {
          player.isEliminated = true;
        } else {
          if (player.currentQuestionIndex < questions.length - 1) {
            player.currentQuestionIndex++;
          } else {
            player.hasFinished = true;
          }
        }
        
        broadcastState();
        
        // Check if all players finished for podium
        const allFinished = Object.values(gameState.players).every(p => p.isEliminated || p.hasFinished);
        if (allFinished && Object.keys(gameState.players).length > 0) {
          gameState.phase = 'podium';
          broadcastState();
        }
      }
    });

    socket.on("hostAction", (data) => {
      if (data.action === 'start_game' && gameState.phase === 'lobby') {
        gameState.phase = 'active';
        broadcastState();
      }
    });

    socket.on("disconnect", () => {
      // Keep player data for ranking even if disconnected
    });
  });

  return httpServer;
}
