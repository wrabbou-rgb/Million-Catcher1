
import { z } from 'zod';
import { joinGameSchema, betSchema } from './schema';

export const api = {
  // We'll primarily use Socket.IO, but here are some basic API routes if needed
  game: {
    status: {
      method: 'GET' as const,
      path: '/api/game/status' as const,
      responses: {
        200: z.object({
          code: z.string(),
          playerCount: z.number(),
          phase: z.string(),
        }),
      },
    },
  },
};

export const ws = {
  // Client -> Server events
  send: {
    join: joinGameSchema,
    submitBets: betSchema,
    hostAction: z.object({
      action: z.enum(['start_game', 'next_question', 'reveal_answer', 'end_game']),
    }),
  },
  // Server -> Client events
  receive: {
    gameState: z.object({
      phase: z.enum(['lobby', 'question', 'betting', 'result', 'gameover']),
      timeLeft: z.number(),
      currentQuestion: z.object({
        text: z.string(),
        options: z.array(z.string()),
        maxOptionsToBet: z.number(),
        number: z.number(),
        total: z.number(),
      }).optional(),
      correctIndex: z.number().optional(), // Sent only in result phase
      players: z.array(z.object({
        id: z.string(),
        name: z.string(),
        money: z.number(),
        isEliminated: z.boolean(),
        lastBet: z.record(z.string(), z.number()).optional(), // For host view
      })),
    }),
    playerUpdate: z.object({
      money: z.number(),
      isEliminated: z.boolean(),
    }),
    error: z.object({
      message: z.string(),
    }),
  },
};
