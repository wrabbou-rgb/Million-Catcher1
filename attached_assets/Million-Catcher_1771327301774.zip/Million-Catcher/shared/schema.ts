import { pgTable, text, serial, integer, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const questions = pgTable("questions", {
  id: serial("id").primaryKey(),
  text: text("text").notNull(),
  options: jsonb("options").notNull().$type<string[]>(), 
  correctIndex: integer("correct_index").notNull(),
  maxoptionsToBet: integer("max_options_to_bet").notNull(), 
});

export const players = pgTable("players", {
  id: text("id").primaryKey(), 
  name: text("name").notNull(),
  money: integer("money").notNull().default(1000000),
  isEliminated: boolean("is_eliminated").notNull().default(false),
  currentQuestionIndex: integer("current_question_index").notNull().default(0),
});

export const joinGameSchema = z.object({
  name: z.string().min(1).max(20),
  code: z.string().length(6),
});

export const createRoomSchema = z.object({
  hostName: z.string().min(1).max(20),
  maxPlayers: z.number().min(2).max(30),
});

export const betSchema = z.object({
  bets: z.record(z.string(), z.number()), 
});

export type Question = typeof questions.$inferSelect;
export type Player = typeof players.$inferSelect;

export interface GameState {
  code: string;
  phase: 'setup' | 'lobby' | 'active' | 'podium';
  players: (Player & { questionNumber: number; hasFinished: boolean; totalQuestions: number })[];
  maxPlayers: number;
  hostName: string;
}
