# Replit Agent Configuration

## Overview

"Atrapa un Milió" is a multiplayer classroom quiz game inspired by the Spanish TV show "Atrapa un Millón," themed around the Otto Cycle Engine. The entire interface is in **Catalan**. Players join via a 6-character game code, start with 1,000,000€, and bet portions of their money on answer options across 8 questions. Wrong bets mean elimination. A host projects the game on a classroom screen while players interact from their phones/computers.

The app is a full-stack TypeScript project with a React frontend (Vite), an Express backend, real-time communication via Socket.IO, and PostgreSQL via Drizzle ORM (though the active game state is managed in-memory for performance).

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend (client/)
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite with HMR support
- **Routing**: Wouter (lightweight client-side router)
- **State Management**: TanStack React Query for server state; local React state + Socket.IO for real-time game state
- **UI Components**: shadcn/ui (new-york style) built on Radix UI primitives with Tailwind CSS
- **Animations**: Framer Motion for money bundles, transitions, and game effects
- **Real-time**: socket.io-client connecting to the same origin server
- **Styling**: Tailwind CSS with CSS variables for theming; custom dark game-show theme with Montserrat and Russo One fonts

### Key Pages
- `/` — Welcome screen with player/host selection
- `/lobby` — Player join screen (name + game code input)
- `/host` — Host dashboard projected in classroom (game code display, player list, rankings, game controls)
- `/game` — Player game screen (question display, betting interface, results)

### Custom Components
- `MoneyBundle` — Visual money stack with animations
- `OptionCard` — Answer option with bet amount display and trapdoor animation for wrong answers

### Backend (server/)
- **Runtime**: Node.js with Express 5
- **Real-time**: Socket.IO server attached to HTTP server
- **Game Logic**: Entirely event-driven via WebSocket events (join, submitBets, hostAction)
- **Game State**: Managed in-memory (not persisted to database) — includes players, bets, current question, phase transitions
- **Phases**: lobby → question → betting → result → (repeat) → gameover → podium

### Socket.IO Events
- **Client → Server**: `join` (name + code), `submitBets` (bets object), `hostAction` (start_game, next_question, reveal_answer, end_game)
- **Server → Client**: `gameState` (broadcast full state), `joined` (confirmation), `error` (error messages), `eliminated`, `gameOver`

### Data Storage
- **PostgreSQL** via Drizzle ORM — schema defined in `shared/schema.ts` with `questions` and `players` tables
- **In practice**: The game uses `MemStorage` class in `server/storage.ts` with hardcoded questions in memory. The database tables exist for validation schemas and potential future persistence
- **Schema push**: Use `npm run db:push` (drizzle-kit push) to sync schema to database
- **Connection**: `DATABASE_URL` environment variable required

### Shared Code (shared/)
- `schema.ts` — Drizzle table definitions, Zod validation schemas (joinGameSchema, betSchema), TypeScript types
- `routes.ts` — API route definitions and WebSocket event schemas (mostly informational, game runs via Socket.IO)

### Game Mechanics
- 8 questions about the Otto Cycle Engine (all in Catalan)
- Questions 1-3: 4 options, bet on up to 3
- Questions 4-7: 3 options, bet on up to 2  
- Question 8: 2 options, all-or-nothing
- Starting balance: 1,000,000€
- If you don't bet on the correct answer → eliminated
- Your next balance = what you bet on the correct answer

### Build System
- **Dev**: `tsx server/index.ts` with Vite dev server middleware
- **Build**: Custom script (`script/build.ts`) using Vite for client and esbuild for server
- **Production**: Compiled to `dist/` — server as `dist/index.cjs`, client as `dist/public/`

### Path Aliases
- `@/*` → `client/src/*`
- `@shared/*` → `shared/*`
- `@assets` → `attached_assets/`

## External Dependencies

### Database
- **PostgreSQL** — Required, connection via `DATABASE_URL` environment variable
- **Drizzle ORM** — Query builder and schema management
- **connect-pg-simple** — Session store (available but sessions not actively used for this game type)

### Real-time Communication
- **Socket.IO** — Server and client for bidirectional WebSocket communication

### UI Framework
- **shadcn/ui** — Full component library (accordion, dialog, tabs, toast, etc.)
- **Radix UI** — Underlying accessible primitives
- **Tailwind CSS** — Utility-first styling
- **Framer Motion** — Animation library
- **Lucide React** — Icon set

### Build & Dev Tools
- **Vite** — Frontend bundler with React plugin
- **esbuild** — Server bundler for production
- **tsx** — TypeScript execution for development
- **drizzle-kit** — Database migration/push tooling
- **@replit/vite-plugin-runtime-error-modal** — Dev error overlay
- **@replit/vite-plugin-cartographer** and **@replit/vite-plugin-dev-banner** — Replit-specific dev plugins

### Validation
- **Zod** — Schema validation for game events and API data
- **drizzle-zod** — Generates Zod schemas from Drizzle table definitions